document.getElementById('submitButton').addEventListener('click',function(){
    window.location.href = window.location.href;
  });

  