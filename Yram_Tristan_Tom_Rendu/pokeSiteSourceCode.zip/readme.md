Intallation process 
1. Turn up an apache and mySql server  
  
2. place the Pokedex-WebSite folder in your localhost  
  
3. open on an editor the file Pokedex-WebSite/database/config.php and configure as necessary  
  
4. open on web the page [http://localhost/Pokedex-WebSite/database/loadDataIntoWebsite.php](http://localhost/Pokedex-WebSite/database/loadDataIntoWebsite.php)  
  
5. once it's done, you can get back on [http://localhost/Pokedex-WebSite](http://localhost/Pokedex-WebSite) and start using the pokesite  